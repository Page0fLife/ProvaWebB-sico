function idade(){
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var date = document.getElementById('date').value;
    var idade = 0;
    idade = 2023-parseInt(date);
    if(nome != "" && email != ""){
        if(idade<18){
            alert("Cadastro não permitido!!! Você tem "+ idade +" anos, saia do site!!!");
        }else{
            alert("Parabéns " + nome + "! Cadastro realizado com sucesso!! Uma mensagem será enviada para " + email + "!!");
        }
    }else{
        alert("Termine de preencher o cadastro!!");
    }
}